using System;
using Xunit;

namespace DataAuthority.Functional.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Post_PayLoad()
        {

        }
    }
}
