﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataAuthority.Base64Left.API.ViewModel
{
    public class CreatePayLoadViewModel
    {
        public string Data { get; set; }
    }
}
