﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace DataAuthority.Domain.UnitTest
{
    public class PayLoadCreatedDomainEventTest
    {
        //[Fact]
        //public void DomainEvent_Call_Differ_If_ThereAre_two_Payloads()
        //{

        //    //I want to check if DataValidator.Diff()
        //    //
        //}
    }
}
